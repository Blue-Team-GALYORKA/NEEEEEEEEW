#!/usr/bin/env bash
# Установка SecureWatch SIEM на Kali Linux (подходит и для Debian 12+/Ubuntu 22.04+).
#
#   sudo ./scripts/install-kali.sh                    # сервер на 127.0.0.1:8080 + агент этой машины
#   sudo ./scripts/install-kali.sh --listen 0.0.0.0   # принимать агенты/syslog с других хостов
#   sudo ./scripts/install-kali.sh --demo             # сразу прогнать демо-атаки
#
# Что делает: ставит python3-venv, копирует проект в /opt/securewatch-siem, создаёт venv,
# генерирует .env (ключ и пароль администратора), регистрирует службы systemd
# securewatch-siem (сервер) и securewatch-agent (агент, читающий journald и логи веб-сервера).
# Повторный запуск безопасен: .env, база и токен агента сохраняются.
set -euo pipefail

INSTALL_DIR=/opt/securewatch-siem
DATA_DIR=/var/lib/securewatch-siem
AGENT_STATE_DIR=/var/lib/securewatch-agent
AGENT_ENV=/etc/securewatch-agent.env
SERVICE_USER=securewatch
AGENT_USER=securewatch-agent

LISTEN=127.0.0.1
PORT=8080
SYSLOG_PORT=5514
WITH_AGENT=1
DEMO=0

usage() {
    sed -n '2,13p' "$0" | sed 's/^# \{0,1\}//'
    echo
    echo "Параметры: --listen АДРЕС  --port ПОРТ  --syslog-port ПОРТ (0 — выкл.)  --no-agent  --demo"
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --listen) LISTEN="$2"; shift 2 ;;
        --port) PORT="$2"; shift 2 ;;
        --syslog-port) SYSLOG_PORT="$2"; shift 2 ;;
        --no-agent) WITH_AGENT=0; shift ;;
        --demo) DEMO=1; shift ;;
        -h|--help) usage; exit 0 ;;
        *) echo "Неизвестный параметр: $1" >&2; usage; exit 1 ;;
    esac
done

[[ "$PORT" =~ ^[0-9]+$ && "$SYSLOG_PORT" =~ ^[0-9]+$ ]] || { echo "Порт должен быть числом" >&2; exit 1; }

say()  { printf '\033[1;34m[SIEM]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[SIEM]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31m[SIEM]\033[0m %s\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Запустите через sudo: sudo $0 $*"

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
[[ -f "$SRC_DIR/app.py" && -d "$SRC_DIR/siem" ]] || die "Скрипт должен лежать в папке scripts/ проекта SecureWatch SIEM"

# ---------- 1. система ----------
if [[ -r /etc/os-release ]]; then
    . /etc/os-release
    say "Система: ${PRETTY_NAME:-неизвестно}"
    if [[ "${ID:-}" != "kali" && " ${ID_LIKE:-} " != *" debian "* && "${ID:-}" != "debian" ]]; then
        warn "Скрипт рассчитан на Kali/Debian. Продолжаю, но apt может не сработать."
    fi
fi

HAS_SYSTEMD=0
[[ -d /run/systemd/system ]] && HAS_SYSTEMD=1

say "Устанавливаю пакеты (python3, venv)…"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq || warn "apt-get update завершился с ошибкой — проверьте зеркала Kali в /etc/apt/sources.list"
apt-get install -y -qq python3 python3-venv python3-pip curl >/dev/null

python3 - <<'PY' || die "Нужен Python 3.10 или новее"
import sys
sys.exit(0 if sys.version_info >= (3, 10) else 1)
PY

# ---------- 2. пользователи ----------
if ! id "$SERVICE_USER" &>/dev/null; then
    useradd --system --home-dir "$DATA_DIR" --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER"
fi
install -d -m 750 -o "$SERVICE_USER" -g "$SERVICE_USER" "$DATA_DIR"

# ---------- 3. файлы проекта ----------
say "Копирую проект в $INSTALL_DIR…"
install -d -m 755 "$INSTALL_DIR"
if [[ "$SRC_DIR" != "$INSTALL_DIR" ]]; then
    tar -C "$SRC_DIR" --exclude=./.git --exclude=./.venv --exclude=./data --exclude=./.env \
        --exclude='__pycache__' -cf - . | tar -C "$INSTALL_DIR" -xf -
fi
chown -R root:root "$INSTALL_DIR"
chmod +x "$INSTALL_DIR"/scripts/*.sh 2>/dev/null || true

# ---------- 4. виртуальное окружение ----------
say "Создаю виртуальное окружение и ставлю зависимости (нужен интернет)…"
[[ -x "$INSTALL_DIR/.venv/bin/python" ]] || python3 -m venv "$INSTALL_DIR/.venv"
"$INSTALL_DIR/.venv/bin/pip" install -q --upgrade pip
"$INSTALL_DIR/.venv/bin/pip" install -q -r "$INSTALL_DIR/requirements.txt"

# ---------- 5. настройки ----------
ENV_FILE="$INSTALL_DIR/.env"
ADMIN_PASSWORD=""
if [[ ! -f "$ENV_FILE" ]]; then
    say "Генерирую .env…"
    SECRET_KEY="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
    ADMIN_PASSWORD="$(python3 -c 'import secrets; print(secrets.token_urlsafe(12))')"
    umask 027
    cat > "$ENV_FILE" <<EOF
SECRET_KEY=$SECRET_KEY
SIEM_ADMIN_USER=admin
SIEM_ADMIN_PASSWORD=$ADMIN_PASSWORD
SIEM_DATABASE=$DATA_DIR/siem.db
SIEM_KNOWLEDGE_DIR=$INSTALL_DIR/knowledge
SIEM_TIMEZONE=$(cat /etc/timezone 2>/dev/null || echo Europe/Moscow)
SIEM_AGGREGATION_WINDOW=5
SIEM_RETENTION_DAYS=30
SIEM_SYSLOG_PORT=$SYSLOG_PORT
SIEM_LISTEN=$LISTEN
SIEM_PORT=$PORT
COOKIE_SECURE=0
EOF
    umask 022
else
    say ".env уже есть — оставляю как есть"
    sed -i "s/^SIEM_LISTEN=.*/SIEM_LISTEN=$LISTEN/; s/^SIEM_PORT=.*/SIEM_PORT=$PORT/; s/^SIEM_SYSLOG_PORT=.*/SIEM_SYSLOG_PORT=$SYSLOG_PORT/" "$ENV_FILE"
    grep -q '^SIEM_LISTEN=' "$ENV_FILE" || echo "SIEM_LISTEN=$LISTEN" >> "$ENV_FILE"
    grep -q '^SIEM_PORT=' "$ENV_FILE" || echo "SIEM_PORT=$PORT" >> "$ENV_FILE"
fi
chown root:"$SERVICE_USER" "$ENV_FILE"
chmod 640 "$ENV_FILE"

as_service() {  # выполнить команду от имени пользователя службы с настройками из .env
    runuser -u "$SERVICE_USER" -- env -C "$INSTALL_DIR" "$INSTALL_DIR/.venv/bin/python" "$@"
}

as_service -m siem.cli check-rules || die "В базе знаний есть ошибки (см. выше)"

# ---------- 6. служба сервера ----------
if [[ $HAS_SYSTEMD -eq 1 ]]; then
    say "Регистрирую службу securewatch-siem…"
    cat > /etc/systemd/system/securewatch-siem.service <<EOF
[Unit]
Description=SecureWatch SIEM (Blue Team GALYORKA)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$INSTALL_DIR/.venv/bin/python -m uvicorn app:app --host \${SIEM_LISTEN} --port \${SIEM_PORT}
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
LockPersonality=true
ReadWritePaths=$DATA_DIR
CapabilityBoundingSet=
AmbientCapabilities=

[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
    systemctl enable --now securewatch-siem.service >/dev/null
    systemctl restart securewatch-siem.service
else
    warn "systemd не найден (например, Kali в WSL или контейнере) — службы не создаются."
fi

wait_health() {
    for _ in $(seq 1 30); do
        curl -fsS "http://127.0.0.1:$PORT/api/v1/health" >/dev/null 2>&1 && return 0
        sleep 1
    done
    return 1
}

if [[ $HAS_SYSTEMD -eq 1 ]]; then
    if wait_health; then
        say "Сервер отвечает на порту $PORT"
    else
        journalctl -u securewatch-siem -n 30 --no-pager >&2 || true
        die "Сервер не запустился. Логи: journalctl -u securewatch-siem -e"
    fi
fi

# ---------- 7. агент этой машины ----------
if [[ $WITH_AGENT -eq 1 ]]; then
    say "Настраиваю агента для этой машины…"
    if ! id "$AGENT_USER" &>/dev/null; then
        useradd --system --no-create-home --home-dir /nonexistent --shell /usr/sbin/nologin "$AGENT_USER"
    fi
    # чтение journald и /var/log (группы есть не во всех системах — добавляем те, что существуют)
    for group in systemd-journal adm; do
        getent group "$group" >/dev/null && usermod -aG "$group" "$AGENT_USER"
    done
    install -d -m 750 -o "$AGENT_USER" -g "$AGENT_USER" "$AGENT_STATE_DIR"

    if [[ ! -f "$AGENT_ENV" ]]; then
        TOKEN="$(as_service -m siem.cli create-agent "$(hostname)")"
        umask 077
        echo "SIEM_AGENT_TOKEN=$TOKEN" > "$AGENT_ENV"
        umask 022
    fi
    chown root:"$AGENT_USER" "$AGENT_ENV"
    chmod 640 "$AGENT_ENV"

    SOURCES=()
    if command -v journalctl >/dev/null && [[ $HAS_SYSTEMD -eq 1 ]]; then
        SOURCES+=(--journal)
    elif [[ -f /var/log/auth.log ]]; then
        SOURCES+=(--file /var/log/auth.log:syslog)
    fi
    for web_log in /var/log/apache2/access.log /var/log/nginx/access.log; do
        [[ -f "$web_log" ]] && SOURCES+=(--file "$web_log:access")
    done
    [[ ${#SOURCES[@]} -gt 0 ]] || SOURCES+=(--journal)

    if [[ $HAS_SYSTEMD -eq 1 ]]; then
        cat > /etc/systemd/system/securewatch-agent.service <<EOF
[Unit]
Description=SecureWatch SIEM MP agent
After=securewatch-siem.service network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$AGENT_USER
Group=$AGENT_USER
EnvironmentFile=$AGENT_ENV
ExecStart=/usr/bin/python3 $INSTALL_DIR/agent/mp_agent.py --server http://127.0.0.1:$PORT --state $AGENT_STATE_DIR/state.json --hostname %H ${SOURCES[*]}
Restart=always
RestartSec=5
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
ReadWritePaths=$AGENT_STATE_DIR

[Install]
WantedBy=multi-user.target
EOF
        systemctl daemon-reload
        systemctl enable --now securewatch-agent.service >/dev/null
        systemctl restart securewatch-agent.service
        say "Агент читает: ${SOURCES[*]}"
    fi
fi

# ---------- 8. демо ----------
if [[ $DEMO -eq 1 && $HAS_SYSTEMD -eq 1 ]]; then
    say "Запускаю демо-атаки…"
    DEMO_TOKEN="$(as_service -m siem.cli create-agent demo-simulator)"
    python3 "$INSTALL_DIR/tools/simulate_attack.py" --server "http://127.0.0.1:$PORT" --token "$DEMO_TOKEN"
fi

# ---------- итог ----------
URL_HOST="$LISTEN"
if [[ "$LISTEN" == "0.0.0.0" ]]; then
    URL_HOST="$(hostname -I 2>/dev/null | awk '{print $1}')"
    URL_HOST="${URL_HOST:-127.0.0.1}"
fi

echo
say "Готово!"
echo "  Интерфейс:       http://$URL_HOST:$PORT"
echo "  Логин:           admin"
if [[ -n "$ADMIN_PASSWORD" ]]; then
    echo "  Пароль:          $ADMIN_PASSWORD   (сохранён в $ENV_FILE)"
else
    echo "  Пароль:          sudo grep SIEM_ADMIN_PASSWORD $ENV_FILE"
fi
if [[ $HAS_SYSTEMD -eq 1 ]]; then
    echo "  Статус:          systemctl status securewatch-siem securewatch-agent"
    echo "  Логи:            journalctl -u securewatch-siem -f"
else
    echo "  Запуск вручную:  cd $INSTALL_DIR && sudo -u $SERVICE_USER .venv/bin/python -m uvicorn app:app --host $LISTEN --port $PORT"
fi
if [[ "$LISTEN" == "0.0.0.0" ]]; then
    echo "  Другие хосты:    создайте токен в разделе «Агенты» и запустите на хосте"
    echo "                   python3 mp_agent.py --server http://$URL_HOST:$PORT --token swa_… --journal"
    [[ "$SYSLOG_PORT" != "0" ]] && echo "  Syslog:          UDP $URL_HOST:$SYSLOG_PORT"
fi
echo "  Удаление:        sudo $INSTALL_DIR/scripts/uninstall-kali.sh"
