#!/usr/bin/env bash
# Удаление SecureWatch SIEM, установленного scripts/install-kali.sh.
#
#   sudo ./uninstall-kali.sh           # удалить службы и программу, база событий останется
#   sudo ./uninstall-kali.sh --purge   # удалить также базу, токен агента и системных пользователей
set -euo pipefail

PURGE=0
[[ "${1:-}" == "--purge" ]] && PURGE=1
[[ $EUID -eq 0 ]] || { echo "Запустите через sudo" >&2; exit 1; }

for unit in securewatch-agent securewatch-siem; do
    if [[ -f /etc/systemd/system/$unit.service ]]; then
        systemctl disable --now "$unit.service" 2>/dev/null || true
        rm -f "/etc/systemd/system/$unit.service"
    fi
done
command -v systemctl >/dev/null && systemctl daemon-reload 2>/dev/null || true

rm -rf /opt/securewatch-siem
echo "[SIEM] Программа и службы удалены."

if [[ $PURGE -eq 1 ]]; then
    rm -rf /var/lib/securewatch-siem /var/lib/securewatch-agent
    rm -f /etc/securewatch-agent.env
    for user in securewatch-agent securewatch; do
        id "$user" &>/dev/null && userdel "$user" 2>/dev/null || true
    done
    echo "[SIEM] База событий, токен агента и пользователи удалены."
else
    echo "[SIEM] База событий сохранена в /var/lib/securewatch-siem (удалить: --purge)."
fi
