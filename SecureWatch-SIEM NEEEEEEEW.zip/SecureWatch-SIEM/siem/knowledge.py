"""База знаний «вендора» — на схеме «пополнение инф. вендора».

Каталог knowledge/:
  rules/*.yaml      — правила корреляции
  ioc/*.txt         — индикаторы компрометации (вредоносные IP), по одному в строке:
                      1.2.3.4            # комментарий
                      203.0.113.0/24     # можно подсеть

Базу можно пополнять без перезапуска: кнопка «Обновить базу знаний» в разделе «Правила».
"""

import ipaddress
import threading
from datetime import datetime, timezone
from pathlib import Path

import yaml

RULE_TYPES = {"single", "threshold", "sequence"}
SEVERITIES = ("low", "medium", "high", "critical")


class RuleError(ValueError):
    pass


def validate_rule(rule: dict, origin: str) -> dict:
    for key in ("id", "name", "type", "severity"):
        if not rule.get(key):
            raise RuleError(f"{origin}: нет обязательного поля «{key}»")
    if rule["type"] not in RULE_TYPES:
        raise RuleError(f"{origin}: неизвестный тип правила {rule['type']!r}")
    if rule["severity"] not in SEVERITIES:
        raise RuleError(f"{origin}: severity должен быть одним из {SEVERITIES}")
    if rule["type"] in ("single", "threshold") and not isinstance(rule.get("filter"), dict):
        raise RuleError(f"{origin}: для типа {rule['type']} нужен filter")
    if rule["type"] == "threshold" and int(rule.get("threshold", 0)) < 1:
        raise RuleError(f"{origin}: для threshold нужен threshold ≥ 1")
    if rule["type"] == "sequence":
        steps = rule.get("steps")
        if not isinstance(steps, list) or len(steps) < 2 or not all(isinstance(s, dict) for s in steps):
            raise RuleError(f"{origin}: для sequence нужно минимум два шага в steps")
    rule.setdefault("window", 300)
    rule.setdefault("group_by", [])
    rule.setdefault("enabled", True)
    rule["window"] = int(rule["window"])
    return rule


class KnowledgeBase:
    def __init__(self, directory):
        self.directory = Path(directory)
        self._lock = threading.Lock()
        self.rules = []
        self.ioc_ips = {}       # ip -> комментарий
        self.ioc_networks = []  # (network, комментарий)
        self.errors = []
        self.loaded_at = None
        self.reload()

    def reload(self):
        rules, errors, seen = [], [], set()
        for path in sorted((self.directory / "rules").glob("*.y*ml")):
            try:
                documents = list(yaml.safe_load_all(path.read_text(encoding="utf-8")))
            except (OSError, yaml.YAMLError) as exc:
                errors.append(f"{path.name}: {exc}")
                continue
            for doc in documents:
                items = doc if isinstance(doc, list) else [doc]
                for raw in items:
                    if not raw:
                        continue
                    try:
                        rule = validate_rule(dict(raw), path.name)
                    except (RuleError, TypeError, ValueError) as exc:
                        errors.append(str(exc))
                        continue
                    if rule["id"] in seen:
                        errors.append(f"{path.name}: повтор id {rule['id']}")
                        continue
                    seen.add(rule["id"])
                    rule["file"] = path.name
                    rules.append(rule)

        ips, networks = {}, []
        for path in sorted((self.directory / "ioc").glob("*.txt")):
            try:
                lines = path.read_text(encoding="utf-8").splitlines()
            except OSError as exc:
                errors.append(f"{path.name}: {exc}")
                continue
            for line in lines:
                value, _, comment = line.partition("#")
                value = value.strip()
                if not value:
                    continue
                comment = comment.strip() or path.stem
                try:
                    if "/" in value:
                        networks.append((ipaddress.ip_network(value, strict=False), comment))
                    else:
                        ips[str(ipaddress.ip_address(value))] = comment
                except ValueError:
                    errors.append(f"{path.name}: не IP-адрес: {value}")

        with self._lock:
            self.rules, self.ioc_ips, self.ioc_networks, self.errors = rules, ips, networks, errors
            self.loaded_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
        return {"rules": len(rules), "ioc": len(ips) + len(networks), "errors": errors}

    def lookup_ip(self, value):
        if not value:
            return None
        if value in self.ioc_ips:
            return self.ioc_ips[value]
        try:
            ip = ipaddress.ip_address(value)
        except ValueError:
            return None
        for network, comment in self.ioc_networks:
            if ip.version == network.version and ip in network:
                return comment
        return None
