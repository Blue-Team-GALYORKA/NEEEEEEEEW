"""Aggregator.S — «склеить события».

Одинаковые нормализованные события (тот же хост, действие, пользователь, IP, сообщение…),
пришедшие в течение окна агрегации, объединяются в одно событие с полем count.
Это экономит место в хранилище и не мешает корреляции: правила учитывают count.
"""

import time

SIGNATURE_FIELDS = ("host", "format", "category", "action", "status", "src_ip", "dst_ip",
                    "subject_user", "object", "msg")


class Aggregator:
    def __init__(self, window_seconds: int = 5, max_pending: int = 5000, clock=time.monotonic):
        self.window = max(0, window_seconds)
        self.max_pending = max_pending
        self.clock = clock
        self._pending = {}  # signature -> (первое появление, событие)
        self.stats = {"in": 0, "out": 0}

    @staticmethod
    def signature(event):
        return tuple(event.get(f) for f in SIGNATURE_FIELDS)

    def add(self, event):
        self.stats["in"] += 1
        if self.window == 0:
            return [self._emit(event)]
        key = self.signature(event)
        pending = self._pending.get(key)
        if pending:
            merged = pending[1]
            merged["count"] = merged.get("count", 1) + event.get("count", 1)
            merged["time"] = min(merged["time"], event["time"])
            merged["last_seen"] = max(merged.get("last_seen") or merged["time"], event["time"])
            return []
        event.setdefault("count", 1)
        event["last_seen"] = event["time"]
        self._pending[key] = (self.clock(), event)
        if len(self._pending) > self.max_pending:
            return self.flush(force=True)
        return []

    def flush(self, force: bool = False):
        now = self.clock()
        ready = [k for k, (t, _) in self._pending.items() if force or now - t >= self.window]
        out = [self._emit(self._pending.pop(k)[1]) for k in ready]
        out.sort(key=lambda e: e["time"])
        return out

    def _emit(self, event):
        event.setdefault("count", 1)
        event.setdefault("last_seen", event["time"])
        if event["count"] > 1:
            event.setdefault("tags", []).append("aggregated")
        self.stats["out"] += 1
        return event
