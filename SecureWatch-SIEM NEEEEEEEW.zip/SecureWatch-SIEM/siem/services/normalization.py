"""Normalization.S — разбор (парсинг) сырых логов и приведение к единой схеме события.

На схеме: «для парсинга» → Normalization.S.
Каждая сырая запись превращается в словарь с одинаковыми полями независимо от источника:

    time, host, category, action, status, importance,
    src_ip, dst_ip, subject_user, object, msg, format, raw
"""

import json
import re
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from ..storage import iso, utcnow

MONTHS = {m: i for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], start=1)}

# ---------- заголовки syslog ----------
RE_PRI = re.compile(r"^<(\d{1,3})>")
RE_RFC5424 = re.compile(
    r"^1 (?P<ts>\S+) (?P<host>\S+) (?P<app>\S+) (?P<pid>\S+) (?P<msgid>\S+) (?:-|\[.*?\]) ?(?P<msg>.*)$")
RE_ISO_SYSLOG = re.compile(
    r"^(?P<ts>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?) "
    r"(?P<host>\S+) (?P<app>[^\s:\[]+)(?:\[(?P<pid>\d+)\])?: ?(?P<msg>.*)$")
RE_BSD_SYSLOG = re.compile(
    r"^(?P<mon>[A-Z][a-z]{2}) +(?P<day>\d{1,2}) (?P<time>\d{2}:\d{2}:\d{2}) "
    r"(?P<host>\S+) (?P<app>[^\s:\[]+)(?:\[(?P<pid>\d+)\])?: ?(?P<msg>.*)$")

# ---------- сообщения Linux ----------
RE_SSH_FAIL = re.compile(r"Failed (?:password|publickey) for (?:invalid user )?(?P<user>\S+) from (?P<ip>[\d.:a-fA-F]+) port (?P<port>\d+)")
RE_SSH_OK = re.compile(r"Accepted (?P<method>\S+) for (?P<user>\S+) from (?P<ip>[\d.:a-fA-F]+) port (?P<port>\d+)")
RE_SSH_INVALID = re.compile(r"Invalid user (?P<user>\S*) from (?P<ip>[\d.:a-fA-F]+)")
RE_SUDO = re.compile(r"^\s*(?P<user>\S+) : .*?USER=(?P<target>\S+) ; COMMAND=(?P<cmd>.+)$")
RE_SUDO_FAIL = re.compile(r"^\s*(?P<user>\S+) : .*?(?:incorrect password attempts?|authentication failure)")
RE_USERADD = re.compile(r"new user: name=(?P<user>[^,\s]+)")
RE_GROUP_ADD = re.compile(r"(?:add '(?P<u1>[^']+)' to group '(?P<g1>[^']+)'|user (?P<u2>\S+) added by \S+ to group (?P<g2>\S+))")
RE_PASSWD_CHANGE = re.compile(r"password changed for (?P<user>\S+)")

# ---------- веб-сервер (nginx/apache combined) ----------
RE_ACCESS = re.compile(
    r'^(?P<ip>[\d.:a-fA-F]+) \S+ (?P<user>\S+) \[(?P<ts>[^\]]+)\] '
    r'"(?P<method>[A-Z]+) (?P<path>\S+)[^"]*" (?P<code>\d{3}) (?P<size>\S+)(?: "(?P<ref>[^"]*)" "(?P<ua>[^"]*)")?')

WEB_ATTACKS = [
    ("sqli", re.compile(r"(union(\s|%20|\+)+select|'(\s|%20)*or(\s|%20)+'?1'?=|sleep\(|information_schema|%27(\s|%20|\+)*or)", re.I)),
    ("xss", re.compile(r"(<script|%3cscript|javascript:|onerror=)", re.I)),
    ("path_traversal", re.compile(r"(\.\./|\.\.%2f|%2e%2e/|/etc/passwd)", re.I)),
    ("scanner", re.compile(r"(sqlmap|nikto|nmap|dirbuster|gobuster|wpscan|masscan)", re.I)),
]

# ---------- Windows Event Log ----------
WINDOWS_EVENTS = {
    4624: ("auth", "login", "success", "low"),
    4625: ("auth", "login", "failure", "medium"),
    4634: ("auth", "logout", "success", "low"),
    4672: ("auth", "privileged_login", "success", "medium"),
    4688: ("process", "start", "success", "low"),
    4720: ("account", "create", "success", "medium"),
    4722: ("account", "enable", "success", "low"),
    4724: ("account", "password_reset", "success", "medium"),
    4726: ("account", "delete", "success", "medium"),
    4728: ("account", "add_to_group", "success", "medium"),
    4732: ("account", "add_to_group", "success", "medium"),
    4756: ("account", "add_to_group", "success", "medium"),
    4740: ("account", "lockout", "failure", "medium"),
    1102: ("system", "log_clear", "success", "high"),
    7045: ("system", "service_install", "success", "medium"),
}


def _clean(value):
    if value in (None, "", "-"):
        return None
    return str(value)[:256]


class Normalizer:
    def __init__(self, tz_name: str = "UTC"):
        try:
            self.tz = ZoneInfo(tz_name)
        except Exception:  # неизвестная зона — работаем в UTC
            self.tz = timezone.utc
        self.stats = {"parsed": 0, "unparsed": 0}

    # ---------- время ----------
    def _parse_iso(self, value):
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except ValueError:
            return None
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=self.tz)
        return iso(dt)

    def _parse_bsd(self, mon, day, clock):
        now = datetime.now(self.tz)
        try:
            h, m, s = (int(x) for x in clock.split(":"))
            dt = datetime(now.year, MONTHS[mon], int(day), h, m, s, tzinfo=self.tz)
        except (KeyError, ValueError):
            return None
        if dt > now.replace(microsecond=0) and (dt - now).days > 1:  # лог из прошлого года
            dt = dt.replace(year=now.year - 1)
        return iso(dt)

    @staticmethod
    def _parse_clf(value):
        try:
            return iso(datetime.strptime(value, "%d/%b/%Y:%H:%M:%S %z"))
        except ValueError:
            return None

    # ---------- точка входа ----------
    def normalize(self, record: dict) -> dict:
        """record = {"line": str, "host": str, "source": str, "file": str, "format": str|None}"""
        line = str(record.get("line", ""))[:8192].rstrip("\r\n")
        base = {
            "time": None,
            "received_at": record.get("received_at") or iso(utcnow()),
            "source": record.get("source"),
            "file": record.get("file"),
            "host": _clean(record.get("host")),
            "category": "other",
            "action": "unknown",
            "status": "info",
            "importance": "low",
            "src_ip": None,
            "dst_ip": None,
            "subject_user": None,
            "object": None,
            "msg": line[:1000],
            "format": "raw",
            "raw": line,
        }
        hint = (record.get("format") or "").lower()
        event = None
        stripped = line.lstrip()
        if hint in ("json", "windows") or stripped.startswith("{"):
            event = self._parse_json(stripped, base)
        if event is None and (hint in ("", "access", "nginx", "apache")):
            event = self._parse_access(line, base)
        if event is None:
            event = self._parse_syslog(line, base)
        if event is None:
            event = base
            self.stats["unparsed"] += 1
        else:
            self.stats["parsed"] += 1
        if not event.get("time"):
            event["time"] = event["received_at"]
        return event

    # ---------- JSON: Windows или уже нормализованный ----------
    def _parse_json(self, line, base):
        try:
            data = json.loads(line)
        except ValueError:
            return None
        if not isinstance(data, dict):
            return None
        event = dict(base)
        event_id = data.get("EventID") or data.get("event_id")
        if event_id is not None and str(event_id).isdigit():
            return self._windows(int(event_id), data, event)
        event["format"] = "json"
        for key in ("category", "action", "status", "importance", "src_ip", "dst_ip", "subject_user", "object", "msg"):
            if data.get(key) is not None:
                event[key] = str(data[key])[:1000]
        event["host"] = _clean(data.get("host")) or event["host"]
        if data.get("time"):
            event["time"] = self._parse_iso(data["time"])
        return event

    def _windows(self, event_id, data, event):
        category, action, status, importance = WINDOWS_EVENTS.get(event_id, ("system", f"event_{event_id}", "info", "low"))
        event.update(
            format="windows",
            category=category,
            action=action,
            status=status,
            importance=importance,
            host=_clean(data.get("Computer")) or event["host"],
            src_ip=_clean(data.get("IpAddress")),
            subject_user=_clean(data.get("TargetUserName") or data.get("SubjectUserName")),
            object=_clean(data.get("GroupName") or data.get("NewProcessName") or data.get("ServiceName")),
            msg=str(data.get("Message") or f"Windows EventID {event_id}")[:1000],
            event_code=event_id,
        )
        if event["src_ip"] in ("127.0.0.1", "::1"):
            event["src_ip"] = None
        if data.get("TimeCreated"):
            event["time"] = self._parse_iso(data["TimeCreated"])
        return event

    # ---------- access log ----------
    def _parse_access(self, line, base):
        m = RE_ACCESS.match(line)
        if not m:
            return None
        code = int(m["code"])
        target = f'{m["path"]} {m["ua"] or ""}'
        attack = next((name for name, rx in WEB_ATTACKS if rx.search(target)), None)
        event = dict(base)
        event.update(
            format="access",
            time=self._parse_clf(m["ts"]),
            category="web",
            action="attack_attempt" if attack else "request",
            status="failure" if code >= 400 else "success",
            importance="high" if attack else ("medium" if code in (401, 403) else "low"),
            src_ip=m["ip"],
            subject_user=_clean(m["user"]),
            object=m["path"][:256],
            msg=f'{m["method"]} {m["path"][:200]} → {code}',
            http_method=m["method"],
            http_status=code,
            user_agent=(m["ua"] or "")[:256],
        )
        if attack:
            event["attack"] = attack
        return event

    # ---------- syslog ----------
    def _parse_syslog(self, line, base):
        text = RE_PRI.sub("", line, count=1)
        m = RE_RFC5424.match(text)
        if m:
            ts, host, app, msg = self._parse_iso(m["ts"]), m["host"], m["app"], m["msg"]
        else:
            m = RE_ISO_SYSLOG.match(text)
            if m:
                ts, host, app, msg = self._parse_iso(m["ts"]), m["host"], m["app"], m["msg"]
            else:
                m = RE_BSD_SYSLOG.match(text)
                if not m:
                    return None
                ts, host, app, msg = self._parse_bsd(m["mon"], m["day"], m["time"]), m["host"], m["app"], m["msg"]
        event = dict(base)
        event.update(format="syslog", time=ts, host=_clean(host) or base["host"], msg=msg[:1000], app=app,
                     category="system", action="message")
        self._linux_message(app, msg, event)
        return event

    @staticmethod
    def _linux_message(app, msg, event):
        app = (app or "").lower()
        if app.startswith("sshd"):
            if m := RE_SSH_FAIL.search(msg):
                event.update(category="auth", action="login", status="failure", importance="medium",
                             subject_user=m["user"], src_ip=m["ip"], object="sshd")
            elif m := RE_SSH_OK.search(msg):
                event.update(category="auth", action="login", status="success", importance="low",
                             subject_user=m["user"], src_ip=m["ip"], object="sshd", auth_method=m["method"])
            elif m := RE_SSH_INVALID.search(msg):
                event.update(category="auth", action="login", status="failure", importance="medium",
                             subject_user=m["user"] or None, src_ip=m["ip"], object="sshd")
            return
        if app == "sudo":
            if m := RE_SUDO.search(msg):
                event.update(category="process", action="sudo", status="success", importance="medium",
                             subject_user=m["user"], object=m["cmd"][:256], target_user=m["target"])
            elif m := RE_SUDO_FAIL.search(msg):
                event.update(category="auth", action="sudo", status="failure", importance="medium",
                             subject_user=m["user"])
            return
        if m := RE_USERADD.search(msg):
            event.update(category="account", action="create", status="success", importance="medium",
                         subject_user=m["user"])
        elif m := RE_GROUP_ADD.search(msg):
            event.update(category="account", action="add_to_group", status="success", importance="medium",
                         subject_user=m["u1"] or m["u2"], object=m["g1"] or m["g2"])
        elif m := RE_PASSWD_CHANGE.search(msg):
            event.update(category="account", action="password_change", status="success", importance="low",
                         subject_user=m["user"])
