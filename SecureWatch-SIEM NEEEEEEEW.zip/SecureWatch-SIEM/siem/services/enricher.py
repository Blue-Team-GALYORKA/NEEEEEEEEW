"""Enricher.S — «обогащение данных», «обогатитель сохраняет».

Добавляет к событию контекст, которого не было в исходном логе, и сохраняет событие в хранилище:
  * тип адреса источника (внутренний / внешний);
  * совпадение с индикаторами компрометации из базы знаний вендора (тег ioc);
  * критичность актива (critical_asset);
  * привилегированная учётная запись (privileged_user);
  * событие вне рабочего времени (off_hours).
"""

import ipaddress
from datetime import datetime
from zoneinfo import ZoneInfo

from ..knowledge import KnowledgeBase
from ..storage import Storage

# Внутренние адреса считаем явно: ipaddress.is_private считает «частными»
# и документационные диапазоны (203.0.113.0/24 и т. п.), а это нам не подходит.
INTERNAL_NETWORKS = [ipaddress.ip_network(n) for n in (
    "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10", "127.0.0.0/8",
    "169.254.0.0/16", "::1/128", "fc00::/7", "fe80::/10")]

PRIVILEGED_USERS = {"root", "admin", "administrator", "администратор", "domain admins", "sa", "postgres"}


class Enricher:
    def __init__(self, storage: Storage, knowledge: KnowledgeBase, tz_name="UTC", work_hours=(8, 20)):
        self.storage = storage
        self.knowledge = knowledge
        try:
            self.tz = ZoneInfo(tz_name)
        except Exception:
            self.tz = ZoneInfo("UTC")
        self.work_hours = work_hours
        self.stats = {"enriched": 0, "ioc_hits": 0, "saved": 0}

    def enrich(self, event):
        tags = event.setdefault("tags", [])

        src = event.get("src_ip")
        if src:
            try:
                ip = ipaddress.ip_address(src)
                internal = any(ip.version == n.version and ip in n for n in INTERNAL_NETWORKS)
                tags.append("internal_src" if internal else "external_src")
            except ValueError:
                event["src_ip"] = None
        for field in ("src_ip", "dst_ip"):
            hit = self.knowledge.lookup_ip(event.get(field))
            if hit:
                tags.append("ioc")
                event["ioc"] = {"field": field, "value": event[field], "source": hit}
                event["importance"] = "high"
                self.stats["ioc_hits"] += 1
                break

        if event.get("asset_criticality") in ("high", "critical"):
            tags.append("critical_asset")
        if (event.get("subject_user") or "").lower() in PRIVILEGED_USERS:
            tags.append("privileged_user")

        try:
            local = datetime.fromisoformat(event["time"]).astimezone(self.tz)
            start, end = self.work_hours
            if not (start <= local.hour < end) or local.weekday() >= 5:
                tags.append("off_hours")
        except (KeyError, ValueError, TypeError):
            pass

        event["tags"] = sorted(set(tags))
        self.stats["enriched"] += 1
        return event

    def save(self, event):
        self.storage.save_event(event)
        self.stats["saved"] += 1
        return event
