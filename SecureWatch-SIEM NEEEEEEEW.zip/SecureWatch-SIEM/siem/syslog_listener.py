"""Приём syslog по UDP (второй вход Receiver.S, кроме HTTP API агентов).

Включается переменной SIEM_SYSLOG_PORT (например, 5514). Syslog по UDP не аутентифицируется,
поэтому открывайте порт только во внутренней сети.
"""

import logging
import socket
import threading

log = logging.getLogger("siem.syslog")


class SyslogListener:
    def __init__(self, receiver, port, host="0.0.0.0"):
        self.receiver, self.port, self.host = receiver, port, host
        self._sock = None
        self._thread = None
        self._stop = threading.Event()

    def _run(self):
        while not self._stop.is_set():
            try:
                data, addr = self._sock.recvfrom(8192)
            except socket.timeout:
                continue
            except OSError:
                break
            line = data.decode("utf-8", errors="replace").strip()
            if not line:
                continue
            try:
                self.receiver.accept([line], source=f"syslog:{addr[0]}")
            except (ValueError, OverflowError):
                pass

    def start(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.bind((self.host, self.port))
        self._sock.settimeout(1.0)
        self._thread = threading.Thread(target=self._run, name="siem-syslog", daemon=True)
        self._thread.start()
        log.info("Syslog UDP слушает порт %s", self.port)

    def stop(self):
        self._stop.set()
        if self._sock:
            self._sock.close()
