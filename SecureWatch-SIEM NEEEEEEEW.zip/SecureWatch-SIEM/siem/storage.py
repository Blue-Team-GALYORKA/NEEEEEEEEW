"""Хранилище SIEM на SQLite: события, активы, инциденты, агенты."""

import json
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    time TEXT NOT NULL,
    received_at TEXT NOT NULL,
    source TEXT,
    format TEXT,
    category TEXT,
    action TEXT,
    status TEXT,
    importance TEXT,
    host TEXT,
    src_ip TEXT,
    dst_ip TEXT,
    subject_user TEXT,
    object TEXT,
    msg TEXT,
    count INTEGER NOT NULL DEFAULT 1,
    asset_id INTEGER,
    tags TEXT NOT NULL DEFAULT '[]',
    data TEXT NOT NULL DEFAULT '{}',
    raw TEXT
);
CREATE INDEX IF NOT EXISTS ix_events_time ON events(time);
CREATE INDEX IF NOT EXISTS ix_events_host ON events(host);
CREATE INDEX IF NOT EXISTS ix_events_src_ip ON events(src_ip);

CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hostname TEXT UNIQUE NOT NULL,
    ips TEXT NOT NULL DEFAULT '[]',
    os TEXT,
    criticality TEXT NOT NULL DEFAULT 'medium',
    owner TEXT,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS incidents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_id TEXT NOT NULL,
    title TEXT NOT NULL,
    severity TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'new',
    group_key TEXT NOT NULL,
    host TEXT,
    src_ip TEXT,
    subject_user TEXT,
    description TEXT,
    mitre TEXT,
    event_count INTEGER NOT NULL DEFAULT 0,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    comment TEXT
);
CREATE INDEX IF NOT EXISTS ix_incidents_status ON incidents(status);

CREATE TABLE IF NOT EXISTS incident_events (
    incident_id INTEGER NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    PRIMARY KEY (incident_id, event_id)
);

CREATE TABLE IF NOT EXISTS agents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    token_hash TEXT UNIQUE NOT NULL,
    created_at TEXT NOT NULL,
    last_seen TEXT,
    last_ip TEXT,
    events_received INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 1
);
"""


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


class Storage:
    """Потокобезопасная обёртка над SQLite (одно соединение + блокировка)."""

    def __init__(self, path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._lock = threading.RLock()
        with self._lock:
            self._conn.executescript(SCHEMA)

    # ---------- общие помощники ----------
    def query(self, sql, params=()):
        with self._lock:
            return [dict(r) for r in self._conn.execute(sql, params).fetchall()]

    def query_one(self, sql, params=()):
        rows = self.query(sql, params)
        return rows[0] if rows else None

    def execute(self, sql, params=()):
        with self._lock:
            cur = self._conn.execute(sql, params)
            self._conn.commit()
            return cur.lastrowid

    # ---------- события ----------
    EVENT_COLUMNS = (
        "time", "received_at", "source", "format", "category", "action", "status",
        "importance", "host", "src_ip", "dst_ip", "subject_user", "object", "msg",
        "count", "asset_id", "raw",
    )

    def save_event(self, event: dict) -> int:
        values = [event.get(c) for c in self.EVENT_COLUMNS]
        extra = {k: v for k, v in event.items() if k not in self.EVENT_COLUMNS and k not in {"id", "tags"}}
        sql = (
            f"INSERT INTO events ({', '.join(self.EVENT_COLUMNS)}, tags, data) "
            f"VALUES ({', '.join('?' * len(self.EVENT_COLUMNS))}, ?, ?)"
        )
        event_id = self.execute(
            sql,
            (*values, json.dumps(event.get("tags", []), ensure_ascii=False),
             json.dumps(extra, ensure_ascii=False, default=str)),
        )
        event["id"] = event_id
        return event_id

    @staticmethod
    def _decode_event(row):
        if row is None:
            return None
        row["tags"] = json.loads(row.get("tags") or "[]")
        row["data"] = json.loads(row.get("data") or "{}")
        return row

    def get_event(self, event_id: int):
        return self._decode_event(self.query_one("SELECT * FROM events WHERE id=?", (event_id,)))

    def search_events(self, *, text="", host="", src_ip="", category="", status="", limit=100, offset=0):
        where, params = [], []
        if text:
            where.append("(msg LIKE ? OR raw LIKE ? OR subject_user LIKE ?)")
            params += [f"%{text}%"] * 3
        for column, value in (("host", host), ("src_ip", src_ip), ("category", category), ("status", status)):
            if value:
                where.append(f"{column} = ?")
                params.append(value)
        clause = f"WHERE {' AND '.join(where)}" if where else ""
        total = self.query_one(f"SELECT COUNT(*) AS n FROM events {clause}", params)["n"]
        rows = self.query(
            f"SELECT * FROM events {clause} ORDER BY time DESC, id DESC LIMIT ? OFFSET ?",
            (*params, limit, offset),
        )
        return [self._decode_event(r) for r in rows], total

    def purge_old_events(self, days: int) -> int:
        cutoff = iso(utcnow() - timedelta(days=days))
        with self._lock:
            cur = self._conn.execute(
                "DELETE FROM events WHERE time < ? AND id NOT IN (SELECT event_id FROM incident_events)",
                (cutoff,),
            )
            self._conn.commit()
            return cur.rowcount

    # ---------- статистика ----------
    def stats(self):
        since = iso(utcnow() - timedelta(hours=24))
        return {
            "events_total": self.query_one("SELECT COALESCE(SUM(count),0) AS n FROM events")["n"],
            "events_24h": self.query_one("SELECT COALESCE(SUM(count),0) AS n FROM events WHERE time >= ?", (since,))["n"],
            "incidents_open": self.query_one("SELECT COUNT(*) AS n FROM incidents WHERE status IN ('new','in_progress')")["n"],
            "assets": self.query_one("SELECT COUNT(*) AS n FROM assets")["n"],
            "by_severity": {
                r["severity"]: r["n"] for r in self.query(
                    "SELECT severity, COUNT(*) AS n FROM incidents WHERE status IN ('new','in_progress') GROUP BY severity")
            },
            "top_src_ips": self.query(
                "SELECT src_ip, SUM(count) AS n FROM events WHERE src_ip IS NOT NULL AND src_ip != '' AND time >= ? "
                "GROUP BY src_ip ORDER BY n DESC LIMIT 5", (since,)),
            "top_hosts": self.query(
                "SELECT host, SUM(count) AS n FROM events WHERE host IS NOT NULL AND time >= ? "
                "GROUP BY host ORDER BY n DESC LIMIT 5", (since,)),
            "by_category": self.query(
                "SELECT category, SUM(count) AS n FROM events WHERE time >= ? GROUP BY category ORDER BY n DESC", (since,)),
        }
