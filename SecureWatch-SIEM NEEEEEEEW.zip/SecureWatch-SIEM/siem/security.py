"""Пароли, CSRF и токены агентов."""

import hashlib
import hmac
import secrets
import time
from collections import defaultdict, deque


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return f"scrypt${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, salt_hex, digest_hex = stored.split("$")
    except ValueError:
        return False
    candidate = hash_password(password, bytes.fromhex(salt_hex)).split("$")[2]
    return hmac.compare_digest(candidate, digest_hex)


def new_agent_token() -> str:
    return "swa_" + secrets.token_urlsafe(32)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def csrf_token(session) -> str:
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]


def check_csrf(session, value) -> bool:
    expected = session.get("csrf")
    return bool(expected and value and hmac.compare_digest(str(expected), str(value)))


class LoginLimiter:
    """Не больше max_attempts неудачных входов с одного IP за window секунд."""

    def __init__(self, max_attempts=5, window=300):
        self.max_attempts, self.window = max_attempts, window
        self._attempts = defaultdict(deque)

    def blocked(self, ip) -> bool:
        attempts = self._attempts[ip]
        now = time.monotonic()
        while attempts and now - attempts[0] > self.window:
            attempts.popleft()
        return len(attempts) >= self.max_attempts

    def fail(self, ip):
        self._attempts[ip].append(time.monotonic())

    def reset(self, ip):
        self._attempts.pop(ip, None)
