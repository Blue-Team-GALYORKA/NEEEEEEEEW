"""Служебные команды SecureWatch SIEM.

    python -m siem.cli create-agent kali-local     # создать агента и напечатать токен
    python -m siem.cli check-rules                 # проверить базу знаний вендора
    python -m siem.cli stats                       # краткая статистика из базы
"""

import argparse
import json
import sys

from .config import settings
from .knowledge import KnowledgeBase
from .security import new_agent_token, token_hash
from .storage import Storage, iso, utcnow


def create_agent(args):
    storage = Storage(settings.database_path)
    token = new_agent_token()
    storage.execute("INSERT INTO agents (name, token_hash, created_at) VALUES (?, ?, ?)",
                    (args.name[:100], token_hash(token), iso(utcnow())))
    print(token)


def check_rules(args):
    kb = KnowledgeBase(settings.knowledge_dir)
    print(f"Правил: {len(kb.rules)}, IoC: {len(kb.ioc_ips) + len(kb.ioc_networks)}")
    for error in kb.errors:
        print(f"ОШИБКА: {error}", file=sys.stderr)
    return 1 if kb.errors else 0


def stats(args):
    print(json.dumps(Storage(settings.database_path).stats(), ensure_ascii=False, indent=2))


def main(argv=None):
    parser = argparse.ArgumentParser(prog="python -m siem.cli", description="SecureWatch SIEM")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("create-agent", help="создать токен агента")
    p.add_argument("name")
    p.set_defaults(func=create_agent)
    sub.add_parser("check-rules", help="проверить правила и IoC").set_defaults(func=check_rules)
    sub.add_parser("stats", help="статистика").set_defaults(func=stats)
    args = parser.parse_args(argv)
    return args.func(args) or 0


if __name__ == "__main__":
    sys.exit(main())
